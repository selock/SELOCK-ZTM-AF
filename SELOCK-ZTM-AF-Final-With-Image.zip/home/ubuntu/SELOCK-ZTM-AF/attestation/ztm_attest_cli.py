#!/usr/bin/env python3
"""
SELOCK ZTM-AF: ZTMAttest CLI Tool
Ferramenta de linha de comando para gerar e verificar provas de attestation soberana.
"""

import argparse
import json
import os
from ztm_proof_generator import ZTMProofGenerator

def generate_proof_command(args):
    print("--- SELOCK ZTMAttest: Gerar Prova ---")
    generator = ZTMProofGenerator(args.device_id, args.build_hash, args.policy_version)
    proof = generator.generate_ztm_proof()
    output_file = generator.save_ztm_proof(proof, filename=args.output)
    print(f"[SUCCESS] Prova de attestation gerada e salva em: {output_file}")

def verify_proof_command(args):
    print("--- SELOCK ZTMAttest: Verificar Prova ---")
    try:
        with open(args.proof_file, 'r') as f:
            proof_data = json.load(f)

        # Simulação de validação da prova
        # Em um cenário real, isso envolveria:
        # 1. Carregar a chave pública do projeto SELOCK.
        # 2. Verificar a assinatura digital (proof_data["hardware_signature"]) usando a chave pública.
        # 3. Comparar o build_hash com um registro oficial de builds da SELOCK.
        # 4. Validar o system_state_hash com base na política aplicada.

        is_valid = True # Simulação de validação bem-sucedida

        print(f"[INFO] Verificando prova: {args.proof_file}")
        print(f"  - Device ID: {proof_data.get('device_id')}")
        print(f"  - Build Hash Oficial: {proof_data.get('official_build_hash')}")
        print(f"  - Política Aplicada: {proof_data.get('applied_policy_version')}")
        print(f"  - Assinatura de Hardware: {proof_data.get('hardware_signature')[:30]}...")

        if is_valid:
            print("[SUCCESS] Prova de attestation verificada com sucesso. Integridade confirmada.")
        else:
            print("[FAILURE] Falha na verificação da prova de attestation. Integridade comprometida.")

    except FileNotFoundError:
        print(f"[ERROR] Arquivo de prova não encontrado: {args.proof_file}")
    except json.JSONDecodeError:
        print(f"[ERROR] Erro ao ler o arquivo JSON de prova: {args.proof_file}")
    except Exception as e:
        print(f"[ERROR] Erro durante a verificação: {e}")

def main():
    parser = argparse.ArgumentParser(description="SELOCK Zero Trust Mobile Attestation Framework (ZTMAttest) CLI")
    subparsers = parser.add_subparsers(dest="command", help="Comandos disponíveis")

    # Subparser para o comando 'generate'
    generate_parser = subparsers.add_parser("generate", help="Gera uma prova de attestation para um dispositivo.")
    generate_parser.add_argument("--device-id", required=True, help="ID único do dispositivo.")
    generate_parser.add_argument("--build-hash", required=True, help="Hash criptográfico da imagem de build oficial.")
    generate_parser.add_argument("--policy-version", required=True, help="Versão da política de hardening aplicada.")
    generate_parser.add_argument("--output", default="ztm_proof.json", help="Nome do arquivo de saída para a prova (padrão: ztm_proof.json).")
    generate_parser.set_defaults(func=generate_proof_command)

    # Subparser para o comando 'verify'
    verify_parser = subparsers.add_parser("verify", help="Verifica uma prova de attestation existente.")
    verify_parser.add_argument("--proof-file", required=True, help="Caminho para o arquivo .ztmproof (JSON) a ser verificado.")
    verify_parser.set_defaults(func=verify_proof_command)

    args = parser.parse_args()
    if hasattr(args, 'func'):
        args.func(args)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
